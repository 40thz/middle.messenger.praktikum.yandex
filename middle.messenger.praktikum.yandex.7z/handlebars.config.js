module.exports = {
  partials: 'src/components',
}

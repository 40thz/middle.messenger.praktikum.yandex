# middle.messenger.praktikum.yandex
 Самостоятельный проект

* Запуск проекта - ```npm start```
* Сборка - ```npm run build```
* Dev Сборка - ```npm run dev```
* Eslint - ```npm run lint```
* Stylelint - ```npm run stylelint```
* Макет - https://www.figma.com/file/oWnGvihu5zIWH6bcyCEYX3/Messenger?node-id=0%3A1&t=L1ceXmvc2UrByKWX-1
* Demo - https://sweet-creponne-8f0591.netlify.app/

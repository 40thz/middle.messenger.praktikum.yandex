export interface IEvents {
  click?: (e?: Event) => void
  blur?: (e?: Event) => void
  focus?: (e?: Event) => void
  submit?: (e?: Event) => void
}

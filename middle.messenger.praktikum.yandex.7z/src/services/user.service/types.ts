export interface IEditPasswordData {
  oldPassword: string
  newPassword: string
}

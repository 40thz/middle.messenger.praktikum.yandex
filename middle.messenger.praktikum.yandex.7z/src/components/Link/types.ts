import { IEvents } from "../../types"

export interface ILink {
  value: string
  color: string
  events?: IEvents
}

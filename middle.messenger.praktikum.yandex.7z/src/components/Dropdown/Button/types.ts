import { DefaultProps } from '../../../modules/Component/types'

export interface IButton extends DefaultProps {
  icon?: string
  name?: string
}

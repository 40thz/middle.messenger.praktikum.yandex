import { DefaultProps } from '../../modules/Component/types'

export interface IBtnUpload extends DefaultProps {
  value: string
}

import avatarImg from '../../../static/Home/Chat/avatar.jpg'

export const carts = [
  {
    avatar: avatarImg,
    name: 'Андрей',
    value: 'Изображение',
    dateTime: '10:49',
    badge: '2',

  },
  {
    avatar: avatarImg,
    name: 'Киноклуб',
    value: 'Вы: стикер',
    dateTime: '12:00',
  },
  {
    avatar: avatarImg,
    name: 'Илья',
    value: 'Друзья, у меня для вас особенный выпуск новостей!...',
    dateTime: '15:12',
    badge: '4',
  },
  {
    avatar: avatarImg,
    name: 'Вадим',
    value: 'Вы: Круто!',
    dateTime: 'Пт',
  },
  {
    avatar: avatarImg,
    name: 'тет-а-теты',
    value: 'И Human Interface Guidelines и Material Design рекомендуют...',
    dateTime: 'Ср',
  },
  {
    avatar: avatarImg,
    name: '1, 2, 3',
    value: 'Миллионы россиян ежедневно проводят десятки часов свое...',
    dateTime: 'Пн',
  },
  {
    avatar: avatarImg,
    name: 'Design Destroyer',
    value: 'В 2008 году художник Jon Rafman  начал собирать...',
    dateTime: 'Пн',
  },
  {
    avatar: avatarImg,
    name: 'Day.',
    value: 'Так увлёкся работой по курсу, что совсем забыл его анонсир...',
    dateTime: '1 Мая 2020',
  },
  {
    avatar: avatarImg,
    name: 'Стас Рогозин',
    value: 'Можно или сегодня или завтра вечером.',
    dateTime: '12 Апр 2020',
  },
  {
    avatar: avatarImg,
    name: 'Андрей',
    value: 'Изображение',
    dateTime: '10:49',
    badge: '2',
  },
  {
    avatar: avatarImg,
    name: 'Илья',
    value: 'Друзья, у меня для вас особенный выпуск новостей!...',
    dateTime: '15:12',
    badge: '4',
  },
  {
    avatar: avatarImg,
    name: 'Вадим',
    value: 'Вы: Круто!',
    dateTime: 'Пт',
  },
  {
    avatar: avatarImg,
    name: 'тет-а-теты',
    value: 'И Human Interface Guidelines и Material Design рекомендуют...',
    dateTime: 'Ср',
  },
  {
    avatar: avatarImg,
    name: '1, 2, 3',
    value: 'Миллионы россиян ежедневно проводят десятки часов свое...',
    dateTime: 'Пн',
  },
  {
    avatar: avatarImg,
    name: 'Design Destroyer',
    value: 'В 2008 году художник Jon Rafman  начал собирать...',
    dateTime: 'Пн',
  },
  {
    avatar: avatarImg,
    name: 'Day.',
    value: 'Так увлёкся работой по курсу, что совсем забыл его анонсир...',
    dateTime: '1 Мая 2020',
  },
  {
    avatar: avatarImg,
    name: 'Стас Рогозин',
    value: 'Можно или сегодня или завтра вечером.',
    dateTime: '12 Апр 2020',
  },
]
